import React from "react";

const Popup = ({orderPopup,setOrderPopup})=> {
    return(
        <div>
            
        </div>
    )
}

export default Popup;