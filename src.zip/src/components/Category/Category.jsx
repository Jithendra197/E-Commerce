import React from "react";
import image1 from "./earphone.png";
import image2 from "./watch-3.png";
import image3 from './macbook.png';

const Category = () => {
  return (
    <div className="py-8 pl-5" id="/category">
      <div className="container ">
        <div className="flex flex-row justify-around">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-2 gap-8">
            <div className="overflow-hidden py-10 pl-5 lg:ml-40 bg-gradient-to-br from-black/90 to-black/70 text-white rounded-3xl relative h-[320px] w-[300px] flex items-end">
              <div>
                <div className="mb-4">
                  <p className="mb-[2px] text-gray-400 font-medium">Enjoy </p>
                  <p className="text-2xl font-semibold mb-[2px]">with</p>
                  <p className="text-4xl xl:text-5xl font-bold opacity-20 mb-2">
                    Earphone
                  </p>
                  <button className="bg-red-600 p-2 pl-4 pr-4 rounded-3xl">
                    Browse
                  </button>
                </div>
              </div>

              <img
                src={image1}
                alt=""
                className="w-[320px] absolute object-cover hover:scale-105 duration-300 bottom-0"
              />
            </div>

            <div className="overflow-hidden py-10 pl-5 bg-gradient-to-br from-yellow-300 to-yellow-400 text-white rounded-3xl relative h-[320px] flex items-center">
              <div>
                <div className="mb-4">
                  <p className="mb-[2px] font-medium text-white">Enjoy </p>
                  <p className="text-2xl text-white font-semibold mb-[2px]">Fabulous</p>
                  <p className="text-4xl xl:text-5xl text-white font-bold opacity-20 mb-2">
                    Smartwatches
                  </p>
                  <button className="bg-white text-yellow-900 font-medium p-2 pl-4 pr-4 rounded-3xl">
                    Browse
                  </button>
                </div>
              </div>

              <img src={image2} alt="" className="w-[320px] absolute hover:scale-115 duration-300 top-0 right-[-70px]"/>
            </div>
            <div className="overflow-hidden py-10 pl-5 bg-gradient-to-br from-red-900 to-red-600 lg:mx-40 text-white rounded-3xl relative h-[320px] lg:w-[860px] md:w-[770px] w-[300px] flex items-end">
              <div className="space-y-2">
                <div className="mb-4">
                  <p className=" text-white font-medium md:text-4xl">Enjoy </p>
                  <p className="text-2xl font-semibold md:text-4xl">with</p>
                  <p className="text-4xl xl:text-7xl font-bold opacity-20 md:text-8xl">
                    Laptops
                  </p>
                  <button className="bg-gray-300 text-red-900 mt-2 p-2 pl-4 pr-4 rounded-3xl">
                    Browse
                  </button>
                </div>
              </div>

              <img
                src={image3}
                alt=""
                className="w-[250px] absolute hover:scale-115 duration-500 top-1/2 -translate-y-1/2 right-0"
              />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Category;
