import React from "react";
import image4 from "./gaming.png";
import image5 from "./vr.png";
import image6 from './speaker.png'

const Category = () => {
  return (
    <div className="py-8 md:ml-13 overflow-x-hidden" id="/category2">
      <div className="container">
        <div className="flex flex-row justify-around ml-5">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-2 gap-8">
            <div className="overflow-hidden py-10 bg-gradient-to-br from-gray-400 to-gray-300 text-white rounded-3xl relative h-[320px] lg:ml-25 lg:w-[400px] w-[300px] flex items-top">
              <div className="space-y-2">
                <div className="mb-4 text-black pl-10">
                  <p className=" text-black font-medium">Enjoy </p>
                  <p className="text-2xl font-semibold ">with</p>
                  <p className="text-4xl xl:text-7xl font-bold opacity-60 ">
                    Gaming
                  </p>
                  <button className="bg-red-700 text-white mt-2 p-2 pl-4 pr-4 rounded-3xl">
                    Browse
                  </button>
                </div>
              </div>

              <img
                src={image4}
                alt=""
                className="w-[180px] lg:w-[250px] absolute hover:scale-110 duration-300 bottom-0 lg:top-1/2 z-40 lg:-translate-y-1/2 right-0"
              />
            </div>

            <div className="overflow-hidden py-5 pl-5 bg-gradient-to-br from-yellow-300 to-yellow-400 text-white sm:left-0 lg:ml-25 rounded-3xl relative h-[320px] md:w-[350px] flex items-top">
              <div>
                <div className="mb-4">
                  <p className="mb-[2px] font-medium text-white">Enjoy </p>
                  <p className="text-2xl text-white font-semibold mb-[2px]">Fabulous</p>
                  <p className="text-4xl xl:text-5xl text-white font-bold opacity-20 mb-2">
                    Smartwatches
                  </p>
                  <button className="bg-white text-yellow-900 font-medium p-2 pl-4 pr-4 rounded-3xl">
                    Browse
                  </button>
                </div>
              </div>

              <img src={image5} alt="" className="w-[220px] absolute hover:scale-110 duration-300 bottom-0 right-0"/>
            </div>
            <div className="overflow-hidden py-6 pl-5 bg-gradient-to-br from-yellow-300 to-yellow-400 text-white rounded-3xl sm:left-0 lg:ml-25 relative h-[320px] md:w-[750px] lg:w-[680px] w-[300px] flex items-top">
              <div>
                <div className="mb-4 absolute top-19 space-y-4">
                  <p className="mb-[2px] text-4xl font-medium text-white">Enjoy </p>
                  <p className=" text-5xl text-white font-semibold mb-[2px]">Fabulous</p>
                  <p className="text-6xl xl:text-5xl text-white font-bold opacity-20 mb-2">
                    Speakers
                  </p>
                  <button className="bg-white text-yellow-900 font-medium p-2 pl-4 pr-4 rounded-3xl">
                    Browse
                  </button>
                </div>
              </div>

              <img src={image6} alt="" className="w-[200px] absolute hover:scale-110 duration-300 bottom-0 right-0"/>
            </div>
            
          </div>
        </div>
      </div>
    </div>
  );
};

export default Category;
