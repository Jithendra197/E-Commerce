import React, { useState,useEffect } from "react";
import { FaShoppingCart } from "react-icons/fa";
import { IoClose } from "react-icons/io5";
import { FiMenu } from "react-icons/fi";
import { Link } from "react-router-dom";

const  NavBar=({cart,onRemove}) =>{
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [count, setCount] = useState(1); // Start from 0

  

  useEffect(()=>{
          localStorage.setItem("cart", JSON.stringify(cart));
      },[cart]);



  const onIncrement = (id) => {
    setCount (prev => ({ ...prev, [id]: (prev[id] || 0) + 1 }));
  };

  // Decrement for specific id
  const onDecrement = (id) => {
    setCount(prev => ({
      ...prev,
      [id]: prev[id] > 0 ? prev[id] - 1 : 0
    }));
  };
  return (
    <>
      {/* Navbar */}
      <nav className="bg-gray-300 shadow-md w-full fixed top-0 left-0 z-80">
        <div className="max-w-7xl mx-auto px-4 py-2 flex justify-between items-center">
          {/* Logo */}
          <div className="flex items-center space-x-6">
            <div className="text-2xl font-bold text-red-600">ESHOP.</div>

            {/* Desktop Menu */}
            <ul className="hidden md:flex space-x-6 text-gray-700 font-medium">
              <Link to="/hero" ><li className="text-black hover:text-white cursor-pointer">Home</li></Link>
              <Link to="/product"><li className="text-black hover:text-white cursor-pointer">Trending</li></Link>
              <li className="text-black hover:text-white cursor-pointer">Electronics</li>
              <li className="text-black hover:text-white cursor-pointer">Blogs</li>
            </ul>
          </div>

          {/* Search Bar (Desktop) */}
          <div className="flex-1 mx-4 hidden md:flex">
            <input
              type="text"
              placeholder="Search..."
              className="w-full border bg-white border-gray-300 rounded-3xl px-4 py-1 focus:outline-none focus:ring-2 focus:ring-blue-400"
            />
          </div>

          {/* Cart + Menu Toggle */}
          <div className="flex items-center space-x-4">
            {/* Cart Icon */}
            {!isCartOpen ? (
              <FaShoppingCart  onClick={() => setIsCartOpen(true)} className="text-2xl text-gray-700 cursor-pointer" />): (<FaShoppingCart
                  className="text-2xl cursor-pointer"
                  onClick={() => setIsCartOpen(!true)}
                />)}
              {cart.length > 0 && (
                <span className="absolute top-1 right-9 lg:right-3  bg-red-500 text-white text-xs rounded-full px-1 py-0">
                  {cart.length}
                </span>
              )}
            
            {/* Menu Toggle Icons */}
            <div className="md:hidden">
              {!isMenuOpen ? (
                <FiMenu
                  className="text-2xl cursor-pointer"
                  onClick={() => setIsMenuOpen(true)}
                />
              ) : (
                <IoClose
                  className="text-2xl cursor-pointer"
                  onClick={() => setIsMenuOpen(!true)}
                />
              )}
            </div>
          </div>
        </div>

        {/* Mobile Menu */}
        {isMenuOpen && (
          <div className="md:hidden px-4 py-3 border-t bg-gray-500">
            <input
              type="text"
              placeholder="Search..."
              className="w-full border bg-white border-gray-300 rounded-2xl px-4 py-1 mb-3 focus:outline-none "
            />
            <ul className="space-y-2 text-gray-700 flex flex-col items-center font-medium">
              <li className="text-black hover:text-white cursor-pointer">Home</li>
              <li className="text-black hover:text-white cursor-pointer">Trending</li>
              <li className="text-black hover:text-white cursor-pointer">Electronics</li>
              <li className="text-black hover:text-white cursor-pointer">Blogs</li>
            </ul>
          </div>
        )}
      </nav>

        {isCartOpen && (
       <div className="fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center z-50">
      <div className="bg-white w-full top-9 h-full sm:w-3/4 sm:h-3/4 rounded-lg shadow-lg p-5 relative overflow-y-auto">
        {/* Close Button */}
        
        <div>
        <h2 className=" text-2xl font-bold mb-4">Your Cart</h2>
        <IoClose
          className="absolute top-5 right-4 text-3xl cursor-pointer"
          onClick={() => setIsCartOpen(false)}/>
        </div>

        {cart.length === 0 ? (
          <p className="text-gray-600">Your cart is Empty.</p>
        ) : (
          <div className="flex flex-col gap-4">
            {cart.map((item, index) => (
              <div
                key={index}
                className="flex justify-between items-center pb-2"
              >
                {/* Product Image & Info */}
                <div className="flex items-center gap-4">
                  <img
                    src={item.img}
                    alt={item.name}
                    className="w-16 h-16 object-cover rounded"
                  />
                  <div >
                    <h3 className="font-semibold">{item.title}</h3>
                    <p className="text-black font-bold">₹{item.price}</p>
                  </div>
                </div>

                {/* Quantity Controls + Remove Button */}
                <div className="flex items-center gap-3">
                  {/* Increment & Decrement Buttons */}
                  <div className="flex items-center gap-2 px-3 py-1 rounded">
                    <button
                      onClick={() => onDecrement(item.id)}
                      className="px-2 py-1 bg-gray-200 hover:bg-gray-300 rounded"
                    >
                      -
                    </button>
                    <span className="px-3 font-semibold"> {count[item.id] || 1}</span>
                    <button
                      onClick={() => onIncrement(item.id)}
                      className="px-2 py-1 bg-gray-200 hover:bg-gray-300 rounded"
                    >
                      +
                    </button>
                  </div>

                  {/* Remove Button */}
                  <button
                    onClick={() => onRemove(item.id)}
                    className="px-3 py-1 bg-red-500 text-white rounded hover:bg-red-600"
                  >
                    Remove
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
        )
      }
      </>
  )
}

      export default NavBar;

     